numero = 0

for soma in range(1, 101):
     numero += soma

print(numero)