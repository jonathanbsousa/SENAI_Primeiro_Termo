cores = ["Vermelho", "Azul", "Verde", "Amarelo"]

for cor in cores:
    print(cor)