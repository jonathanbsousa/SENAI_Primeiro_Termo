numero = float(input("Digite o numero que quer calcular: "))
cont = numero - 1

while cont > 0:
    fato = cont * numero
    cont -= 1

print(fato)