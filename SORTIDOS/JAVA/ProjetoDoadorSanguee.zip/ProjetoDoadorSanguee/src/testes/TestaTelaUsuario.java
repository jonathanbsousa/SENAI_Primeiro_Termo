package testes;

public class TestaTelaUsuario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
