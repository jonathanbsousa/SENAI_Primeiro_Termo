import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Main {
    public static void main(String[] args) {

        // Criar uma matriz
        String[][] matriz = new String[5][10];

        // Preencher a matriz com valores
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 10; j++) {
                matriz[i][j] = "X";
            }
        }

        // Imprimi a matriz
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
            matriz[evento_randomico(matriz)][evento_randomico(matriz)] = "1";
        }

    }

    public static int evento_randomico(String[][] i){
        ArrayList<Integer> lista = new ArrayList<>();
        Random random = new Random();
        return lista.get(random.nextInt(lista.size()));
    }

}
