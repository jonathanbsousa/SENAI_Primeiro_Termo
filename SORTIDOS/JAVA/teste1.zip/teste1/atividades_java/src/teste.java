import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class teste {
    public static void main(String[] args) {
        boolean [] espacos = new boolean[50];
        Random rd = new Random();
        int qtd_peixes = 25;

        while (qtd_peixes > 0){
            for (int i = 0; i < espacos.length; i++){
                if (rd.nextInt(10) == 1 && !espacos[i]){
                    espacos[i] = true;
                    qtd_peixes--;
                }
                if (qtd_peixes == 0){
                    break;
                }

            }
        }

        System.out.println(Arrays.toString(espacos));

        // Preencher a matriz com valores
        for (int i = 0; i < 5; i++) {
                espacos[i] = true;
        }

        // Imprimi a matriz
        for (int i = 0; i < 5; i++) {
            System.out.print(espacos[i] + "\t");
            System.out.println();
            espacos[evento_randomico(espacos)][evento_randomico(espacos)] = true;
        }

    }

    public static int evento_randomico(boolean[] i){
        ArrayList<Integer> lista = new ArrayList<>();
        Random random = new Random();
        return lista.get(random.nextInt(lista.size()));
    }

}

